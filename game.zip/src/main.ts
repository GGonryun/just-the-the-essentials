import Phaser from "phaser";

import { Boot } from "./scenes/boot-scene";
import { Dialog } from "./scenes/dialog-scene";
import { GameOver } from "./scenes/game-over-scene";
import { Play } from "./scenes/play-scene";
import { MainMenu } from "./scenes/main-menu-scene";

import RoundRectanglePlugin from "phaser3-rex-plugins/plugins/roundrectangle-plugin.js";
import { EndingDialog } from "./scenes/ending-dialog-scene";
import { OpeningDialog } from "./scenes/opening-dialog-scene";
import { VolumeMenu } from "./scenes/volume-menu-scene";
import { Credits } from "./scenes/credits-scene";
import { Storyboard } from "./scenes/storyboard-scene";
import { TutorialDialog } from "./scenes/tutorial-scene";

//  Find out more information about the Game Config at:
//  https://newdocs.phaser.io/docs/3.70.0/Phaser.Types.Core.GameConfig
const config: Phaser.Types.Core.GameConfig = {
  type: Phaser.AUTO,
  width: 1024,
  height: 768,
  parent: "game-container",
  backgroundColor: "#028af8",

  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH,
  },
  scene: [
    Boot,
    Play,
    MainMenu,
    Dialog,
    EndingDialog,
    GameOver,
    OpeningDialog,
    Credits,
    VolumeMenu,
    Storyboard,
    TutorialDialog,
  ],
  plugins: {
    global: [
      {
        key: "rexRoundRectanglePlugin",
        plugin: RoundRectanglePlugin,
        start: true,
      },
    ],
  },
};

export default new Phaser.Game(config);
