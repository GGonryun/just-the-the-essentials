export class Storyboard extends Phaser.Scene {
  static key = "StoryboardScene";
  constructor() {
    super(Storyboard.key);
  }

  create() {
    const { height, width } = this.cameras.main;
    this.add
      .image(width * 0.5, height * 0.5, "main-menu-background")
      .setOrigin(0.5)
      .setScale(0.6);

    // add temporary text.
    this.add
      .text(width * 0.5, height * 0.5, "Storyboard Scene", {
        fontSize: "48px",
        color: "#000",
      })
      .setOrigin(0.5);
  }
}
