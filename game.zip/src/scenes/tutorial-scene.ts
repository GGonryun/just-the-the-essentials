import { CHARACTERS } from "../data/characters";
import { EVENTS } from "../data/events";
import { REGISTRY } from "../data/registry";
import { DialogLine } from "../objects/dialog-line";
import { DialogTextBox } from "../objects/dialog-text-box";
import { Portrait } from "../objects/portrait";
import { emitGameEvent } from "../util";
import Phaser from "phaser";

export class TutorialDialog extends Phaser.Scene {
  static key = "TutorialDialog";
  dialogMargin = 64;
  dialogPadding = 16;
  dialogHeight = 200;
  line: DialogLine;
  leftPortrait: Portrait;
  rightPortrait: Portrait;
  dialog: DialogTextBox;
  constructor() {
    super(TutorialDialog.key);
  }

  create() {
    const state = this.registry.get(REGISTRY.KEYS.TUTORIAL);
    console.log("tutorial state", state);
    const { height, width } = this.cameras.main;
    this.add
      .image(width * 0.5, height * 0.5, "main-menu-background")
      .setOrigin(0.5)
      .setScale(0.6);

    const leftPortraitX = width / 4;
    this.leftPortrait = new Portrait(
      this,
      -300,
      height / 2.3,
      false,
      CHARACTERS.MYSTERIOUS_ENTITY.NEUTRAL.key
    ).setAlpha(1);
    this.leftPortrait.setScale(Portrait.scale * 1.1);

    const rightPortraitX = width - width / 4;
    this.rightPortrait = new Portrait(
      this,
      width * 1.5,
      height / 2.3,
      false,
      CHARACTERS.POINTER.NEUTRAL.key
    ).setAlpha(1);
    this.rightPortrait.setScale(Portrait.scale * 1.1);

    this.line = new DialogLine(this);

    const conversationSuccess = [
      {
        title: "Mysterious Entity",
        text: "See! Not so hard is it. Go on then, talk to them all and maybe you can escape.",
        style: "left" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.leftPortrait,
            x: leftPortraitX,
            duration: 1000,
            yoyo: false,
            repeat: 0,
            ease: "Power2",
          });
          this.leftPortrait.setTexture(CHARACTERS.MYSTERIOUS_ENTITY.HAPPY.key);
        },
      },
      {
        title: "Mysterious Entity",
        text: "Oh! almost forgot to mention...",
        style: "left" as const,
        onConversationStart: () => {
          this.leftPortrait.setTexture(
            CHARACTERS.MYSTERIOUS_ENTITY.NEUTRAL.key
          );
        },
      },
      {
        title: "Mysterious Entity",
        text: "If you answer wrong the room will explode with you in it.",
        style: "left" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.leftPortrait,
            scale: "+=0.01",
            duration: 25,
            yoyo: true,
            repeat: 2,
            ease: "Power2",
          });
          this.leftPortrait.setTexture(
            CHARACTERS.MYSTERIOUS_ENTITY.MENACING.key
          );
        },
      },
      {
        title: "Pointer McCursor",
        text: "................................",
        style: "right" as const,
        onConversationStart: () => {
          this.rightPortrait.setTexture(CHARACTERS.POINTER.SURPRISED.key);
          this.tweens.add({
            targets: this.rightPortrait,
            duration: 1000,
            x: rightPortraitX,
            yoyo: false,
            repeat: 0,
          });
        },
      },
      {
        title: "Pointer McCursor",
        text: "Why... Why are you doing this to me?",
        style: "right" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.rightPortrait,
            duration: 25,
            x: "+=10",
            yoyo: true,
            repeat: 3,
          });
        },
      },
      {
        title: "Mysterious Entity",
        text: "Why...?",
        style: "left" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.leftPortrait,
            scale: "+=0.01",
            duration: 25,
            yoyo: true,
            repeat: 2,
            ease: "Power2",
          });
          this.leftPortrait.setTexture(
            CHARACTERS.MYSTERIOUS_ENTITY.CURIOUS.key
          );
        },
      },
      {
        title: "Mysterious Entity",
        text: "Because I'm a comically evil MacGuffin-esque villain!",
        style: "left" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.leftPortrait,
            scale: "+=0.01",
            x: "+=10",
            duration: 25,
            yoyo: true,
            repeat: 3,
            ease: "Power2",
          });
        },
      },
      {
        title: "Mysterious Entity",
        text: "Well then, I'm off! Goooooddd luckkkkk!!",
        style: "left" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.leftPortrait,
            x: -300,
            duration: 1000,
            yoyo: false,
            repeat: 0,
            ease: "Power2",
          });
        },
      },
      {
        title: "Pointer McCursor",
        text: "WAIT! Get back here!!",
        style: "right" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.rightPortrait,
            duration: 33,
            x: "+=10",
            yoyo: true,
            repeat: 3,
          });

          this.rightPortrait.setTexture(CHARACTERS.POINTER.ANGRY.key);
        },
      },
      {
        title: "Pointer McCursor",
        text: "They just... left.",
        style: "right" as const,
      },
      {
        title: "Pointer McCursor",
        text: "I guess I should just play their game. Or at least try to.",
        style: "right" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.rightPortrait,
            duration: 500,
            scale: "-=0.015",
            yoyo: true,
            repeat: 0,
          });

          this.rightPortrait.setTexture(CHARACTERS.POINTER.NEUTRAL.key);
        },
        onConversationEnd: () => {
          // no-op for type safety
        },
      },
    ];

    const conversationFailure = [
      {
        title: "Mysterious Entity",
        text: "Did you... just fail the tutorial? Really??",
        style: "left" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.leftPortrait,
            x: leftPortraitX,
            duration: 1000,
            yoyo: false,
            repeat: 0,
            ease: "Power2",
          });
          this.leftPortrait.setTexture(
            CHARACTERS.MYSTERIOUS_ENTITY.CURIOUS.key
          );
        },
      },
      {
        title: "Mysterious Entity",
        text: "ha... HAHAHAHAHA!",
        style: "left" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.leftPortrait,
            scale: "+=0.01",
            duration: 25,
            yoyo: true,
            repeat: 2,
            ease: "Power2",
          });

          this.leftPortrait.setTexture(CHARACTERS.MYSTERIOUS_ENTITY.HAPPY.key);
        },
      },
      {
        title: "Mysterious Entity",
        text: "I didn't expect to have to tell you this so soon but...",
        style: "left" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.leftPortrait,
            scale: "+=0.01",
            duration: 25,
            yoyo: true,
            repeat: 2,
            ease: "Power2",
          });

          this.leftPortrait.setTexture(CHARACTERS.MYSTERIOUS_ENTITY.HAPPY.key);
        },
      },
      {
        title: "Mysterious Entity",
        text: "Since you answered wrong this room will now explode!",
        style: "left" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.leftPortrait,
            scale: "+=0.01",
            duration: 25,
            yoyo: true,
            repeat: 2,
            ease: "Power2",
          });

          this.leftPortrait.setTexture(
            CHARACTERS.MYSTERIOUS_ENTITY.MENACING.key
          );
        },
      },
      {
        title: "Mysterious Entity",
        text: "Oh. Not with me though. Just you.",
        style: "left" as const,
        onConversationStart: () => {
          this.leftPortrait.setTexture(
            CHARACTERS.MYSTERIOUS_ENTITY.CURIOUS.key
          );
        },
        onConversationEnd: () => {
          this.tweens.add({
            targets: this.leftPortrait,
            x: -300,
            duration: 1000,
            yoyo: false,
            repeat: 0,
            ease: "Power2",
          });
        },
      },
      {
        title: "Pointer McCursor",
        text: "!!!!",
        style: "right" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.rightPortrait,
            duration: 1000,
            x: rightPortraitX,
            yoyo: false,
            repeat: 0,
          });

          this.rightPortrait.setTexture(CHARACTERS.POINTER.SURPRISED.key);
        },
      },
      {
        title: "Pointer McCursor",
        text: "WAIT-",
        style: "right" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.rightPortrait,
            scale: "+=0.01",
            duration: 25,
            yoyo: true,
            repeat: 2,
            ease: "Power2",
          });
        },
      },
    ];

    const conversation = state ? conversationSuccess : conversationFailure;

    this.dialog = new DialogTextBox(
      this,
      this.dialogMargin / 2,
      height - this.dialogHeight,
      {
        margin: this.dialogMargin,
        padding: this.dialogPadding,
        height: this.dialogHeight,
        conversation,
      }
    );

    this.dialog.onPointerDown = () => {
      this.dialog.nextConversation();
    };

    this.dialog.onConversationStart = (step: number) => {
      console.log("Conversation started", step);
      const conv = conversation[step];
      if (conv.style === "left") {
        this.leftPortrait.setAlpha(1);
        this.rightPortrait.setAlpha(0.25);
      } else if (conv.style === "right") {
        this.leftPortrait.setAlpha(0.25);
        this.rightPortrait.setAlpha(1);
      } else {
        this.leftPortrait.setAlpha(1);
        this.rightPortrait.setAlpha(1);
      }

      conv.onConversationStart?.();
    };

    this.dialog.onConversationEnd = (step: number) => {
      console.log("Conversation ended", step);
      const conv = conversation[step];
      conv.onConversationEnd?.();
    };

    this.dialog.onConversationOver = () => {
      emitGameEvent(this, EVENTS.KEYS.CLOSE_TUTORIAL_DIALOG);
    };

    this.dialog.nextConversation();
  }
}
