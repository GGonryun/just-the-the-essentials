import { MainMenu } from "./main-menu-scene";

export class Credits extends Phaser.Scene {
  static key = "Credits";
  constructor() {
    super(Credits.key);
  }

  create() {
    const { height, width } = this.cameras.main;
    this.add
      .image(width * 0.5, height * 0.5, "main-menu-background")
      .setOrigin(0.5)
      .setScale(0.6);

    this.add
      .image(width * 0.5, height * 0.5, "credits-page")
      .setOrigin(0.5)
      .setScale(0.55);

    this.add
      .image(width * 0.2, height * 0.13, "back-button")
      .setOrigin(0.5)
      .setScale(0.1)
      .setInteractive()
      .on("pointerdown", () => {
        this.scene.start(MainMenu.key);
        this.sound.play("flip", {
          rate: 1.5,
        });
      });
  }
}
