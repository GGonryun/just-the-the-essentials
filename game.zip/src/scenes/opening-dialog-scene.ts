import { CHARACTERS } from "../data/characters";
import { DialogLine } from "../objects/dialog-line";
import { DialogTextBox } from "../objects/dialog-text-box";
import { Portrait } from "../objects/portrait";
import { Play } from "./play-scene";
import Phaser from "phaser";

export class OpeningDialog extends Phaser.Scene {
  static key = "OpeningDialog";
  dialogMargin = 64;
  dialogPadding = 16;
  dialogHeight = 200;
  line: DialogLine;
  leftPortrait: Portrait;
  rightPortrait: Portrait;
  dialog: DialogTextBox;
  constructor() {
    super(OpeningDialog.key);
  }

  create() {
    this.sound.stopByKey("dining-clink");
    const { height, width } = this.cameras.main;
    this.add
      .image(width * 0.5, height * 0.5, "main-menu-background")
      .setOrigin(0.5)
      .setScale(0.6);

    const leftPortraitX = width / 4;
    this.leftPortrait = new Portrait(
      this,
      width / 4,
      height / 2.3,
      false,
      CHARACTERS.MYSTERIOUS_ENTITY.NEUTRAL.key
    ).setAlpha(1);
    this.leftPortrait.x = -300;
    this.leftPortrait.setScale(Portrait.scale * 1.1);

    const rightPortraitX = width - width / 4;
    this.rightPortrait = new Portrait(
      this,
      rightPortraitX,
      height / 2.3,
      false,
      CHARACTERS.POINTER.NEUTRAL.key
    ).setAlpha(1);
    this.rightPortrait.x = width * 1.5;
    this.rightPortrait.setScale(Portrait.scale * 1.1);

    this.line = new DialogLine(this);

    let story: Phaser.GameObjects.Image | undefined = undefined;
    const conversation = [
      {
        title: "Pointer McCursor",
        text: "It was supposed to just be another day...",
        style: "none" as const,
        onConversationEnd: () => {
          story = this.add
            .image(-width * 0.5, height * 0.45, "cut-scene-1")
            .setScale(0.5);

          this.tweens.add({
            targets: story,
            duration: 1000,
            x: width * 0.5,
            yoyo: false,
            repeat: 0,
          });
        },
      },
      {
        title: "Pointer McCursor",
        text: "Coming back from my crappy job to my crappy apartment.",
        style: "none" as const,
      },
      {
        title: "Pointer McCursor",
        text: "I had planned on doing some spring cleaning, get rid of things i don't use, and keep just the essentials.",
        style: "none" as const,
      },
      {
        title: "Pointer McCursor",
        text: "It was a day like any other until I opened that door.",
        style: "none" as const,
        onConversationStart: () => {
          if (story) {
            story.destroy();
            story = undefined;
          }

          story = this.add
            .image(width * 0.5, height * 0.45, "cut-scene-2")
            .setScale(0.5);
        },
      },
      {
        title: "Pointer McCursor",
        text: "...............................",
        style: "none" as const,
        onConversationStart: () => {
          if (story) {
            story.destroy();
            story = undefined;
          }

          this.sound.play("door-open");
          story = this.add
            .image(width * 0.5, height * 0.45, "cut-scene-3")
            .setScale(0.5);
        },
      },
      {
        title: "Pointer McCursor",
        text: "?!?!",
        style: "right" as const,
        onConversationStart: () => {
          if (story) {
            story.destroy();
            story = undefined;
          }

          this.tweens.add({
            targets: this.rightPortrait,
            x: rightPortraitX,
            duration: 1000,
            ease: "Power2",
          });
        },
      },
      {
        title: "Pointer McCursor",
        text: "What the hell?!",
        style: "right" as const,
        onConversationStart: () => {
          this.rightPortrait.setTexture(CHARACTERS.POINTER.SURPRISED.key);
          this.tweens.add({
            targets: this.rightPortrait,
            x: "+= 10",
            duration: 25,
            yoyo: true,
            repeat: 5,
            ease: "Power2",
          });
        },
      },
      {
        title: "Mysterious Entity",
        text: "Welcome home",
        style: "left" as const,
      },
      {
        title: "Pointer McCursor",
        text: "What? Who's there??",
        style: "right" as const,
      },
      {
        title: "Mysterious Entity",
        text: "I am who put you in this room",
        style: "left" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.leftPortrait,
            x: leftPortraitX,
            duration: 1000,
            ease: "Power2",
          });
        },
      },
      {
        title: "Pointer McCursor",
        text: "This room... it's my apartment but... where's all my stuff?",
        style: "right" as const,
        onConversationStart: () => {
          this.rightPortrait.setTexture(CHARACTERS.POINTER.NEUTRAL.key);
        },
      },
      {
        title: "Mysterious Entity",
        text: 'You need not worry about your "stuff"',
        style: "left" as const,
      },
      {
        title: "Mysterious Entity",
        text: "Rather, you should now worry about what happens here and now.",
        style: "left" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.leftPortrait,
            scale: "+=0.01",
            duration: 25,
            yoyo: true,
            repeat: 2,
            ease: "Power2",
          });
          this.leftPortrait.setTexture(
            CHARACTERS.MYSTERIOUS_ENTITY.MENACING.key
          );
        },
      },
      {
        title: "Mysterious Entity",
        text: "In this room are objects that you can talk to.",
        style: "left" as const,
        onConversationStart: () => {
          this.leftPortrait.setTexture(
            CHARACTERS.MYSTERIOUS_ENTITY.NEUTRAL.key
          );
        },
      },
      {
        title: "Pointer McCursor",
        text: '"objects" to talk to...?',
        style: "right" as const,
      },
      {
        title: "Mysterious Entity",
        text: "Yes, talking objects is quite par for the course for supervillain magic.",
        style: "left" as const,
      },
      {
        title: "Mysterious Entity",
        text: "I could explain further but that exposition lies outside the scope of a 2-day Game Jam.",
        style: "left" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.leftPortrait,
            scale: "+=0.01",
            duration: 25,
            yoyo: true,
            repeat: 2,
            ease: "Power2",
          });
          this.leftPortrait.setTexture(CHARACTERS.MYSTERIOUS_ENTITY.HAPPY.key);
        },
      },
      {
        title: "Pointer McCursor",
        text: "...What's a Game Ja-",
        style: "right" as const,
      },
      {
        title: "Mysterious Entity",
        text: "WELL! You better get talking. Each object you can talk to has two versions.",
        style: "left" as const,
        onConversationStart: () => {
          this.leftPortrait.setTexture(
            CHARACTERS.MYSTERIOUS_ENTITY.NEUTRAL.key
          );
        },
      },
      {
        title: "Mysterious Entity",
        text: "They will both describe themselves to you.",
        style: "left" as const,
      },
      {
        title: "Mysterious Entity",
        text: "It's your job, through their words alone, to declare which is the real object... and which is the faker.",
        style: "left" as const,
      },
      {
        title: "Mysterious Entity",
        text: "Go on! Try it yourself. Talk to any object here.",
        style: "left" as const,
        onConversationStart: () => {
          this.tweens.add({
            targets: this.leftPortrait,
            scale: "+=0.01",
            duration: 25,
            yoyo: true,
            repeat: 2,
            ease: "Power2",
          });
          this.leftPortrait.setTexture(CHARACTERS.MYSTERIOUS_ENTITY.HAPPY.key);
        },
      },
    ];

    this.dialog = new DialogTextBox(
      this,
      this.dialogMargin / 2,
      height - this.dialogHeight,
      {
        margin: this.dialogMargin,
        padding: this.dialogPadding,
        height: this.dialogHeight,
        conversation,
      }
    );

    this.dialog.onPointerDown = () => {
      this.dialog.nextConversation();
    };

    this.dialog.onConversationStart = (step: number) => {
      console.log("Conversation started", step);
      const conv = conversation[step];
      if (conv.style === "left") {
        this.leftPortrait.setAlpha(1);
        this.rightPortrait.setAlpha(0.25);
      } else if (conv.style === "right") {
        this.leftPortrait.setAlpha(0.25);
        this.rightPortrait.setAlpha(1);
      } else if (conv.style === "none") {
        this.leftPortrait.setAlpha(0);
        this.rightPortrait.setAlpha(0);
      } else {
        this.leftPortrait.setAlpha(1);
        this.rightPortrait.setAlpha(1);
      }

      if (conv.style === "none") {
        this.line.hide();
      } else {
        this.line.show();
      }

      conv.onConversationStart?.();
    };

    this.dialog.onConversationEnd = (step: number) => {
      console.log("Conversation ended", step);
      const conv = conversation[step];
      conv.onConversationEnd?.();
    };

    this.dialog.onConversationOver = () => {
      this.scene.start(Play.key);
    };

    this.input.keyboard?.on(
      "keydown-ESC",
      () => {
        this.scene.start(Play.key);
      },
      this
    );

    this.dialog.nextConversation();
  }
}
