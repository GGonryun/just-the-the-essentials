import { EVENTS } from "../data/events";
import { ActiveItem, ITEMS } from "../data/items";
import { REGISTRY } from "../data/registry";
import { DialogLine } from "../objects/dialog-line";
import { DialogTextBox } from "../objects/dialog-text-box";
import { Portrait } from "../objects/portrait";
import { Play } from "./play-scene";

export class Dialog extends Phaser.Scene {
  static key = "dialog";
  dialogHeight = 200;
  dialogMargin = 64;
  dialogPadding = 16;
  leftPortrait: Portrait;
  rightPortrait: Portrait;
  dialog: DialogTextBox;

  constructor() {
    super(Dialog.key);
  }

  create() {
    const { height, width } = this.cameras.main;
    const active = this.registry.get(REGISTRY.KEYS.ACTIVE) as ActiveItem;
    const item = ITEMS[active.key];
    const dialog = item.dialogs[active.dialogIndex];

    new DialogLine(this);

    this.leftPortrait = new Portrait(
      this,
      width / 4,
      height / 2.75,
      false,
      item.portrait.key
    ).setAlpha(1);

    this.rightPortrait = new Portrait(
      this,
      width - width / 4,
      height / 2.75,
      true,
      item.portrait.key
    ).setAlpha(0.25);

    this.dialog = new DialogTextBox(
      this,
      this.dialogMargin / 2,
      height - this.dialogHeight,
      {
        margin: this.dialogMargin,
        padding: this.dialogPadding,
        height: this.dialogHeight,
        conversation: [
          {
            title: item.name,
            text: dialog.left,
            style: "left",
          },
          {
            title: item.name,
            text: dialog.right,
            style: "right",
          },
          {
            title: item.name,
            text: `Which one is the ${item.name}?`,
            style: "center",
          },
        ],
      }
    );

    this.dialog.onPointerDown = () => {
      this.dialog.nextConversation();
    };

    this.dialog.onConversationStart = (step: number) => {
      if (step === 0) {
        this.leftPortrait.setAlpha(1);
        this.rightPortrait.setAlpha(0.25);
      } else if (step === 1) {
        this.leftPortrait.setAlpha(0.25);
        this.rightPortrait.setAlpha(1);
      } else if (step === 2) {
        // spawn a white rectangle that flashes on the screen
        const rectangle = this.add.rectangle(
          width / 2,
          height / 2,
          width,
          height,
          0xffffff
        );
        rectangle.setAlpha(0);
        this.tweens.add({
          targets: rectangle,
          alpha: 1,
          duration: 75,
          yoyo: true,
          repeat: 0,
          onComplete: () => {
            rectangle.destroy();
          },
        });
        this.sound.play("hits", {
          volume: 0.5,
        });

        this.leftPortrait.setAlpha(1);
        this.rightPortrait.setAlpha(1);
        this.leftPortrait.enableInteractions();
        this.rightPortrait.enableInteractions();
        const current = this.input.activePointer.x;
        if (current < width / 2) {
          this.leftPortrait.setInitialChoice(true);
          this.rightPortrait.setInitialChoice(false);
        } else {
          this.leftPortrait.setInitialChoice(false);
          this.rightPortrait.setInitialChoice(true);
        }
      }
    };

    this.dialog.nextConversation();

    new ExitButton(this);
  }
}

class ExitButton extends Phaser.GameObjects.Image {
  constructor(scene: Phaser.Scene) {
    super(scene, 8, 8, "exit-button");
    this.setOrigin(0);
    this.setInteractive();
    this.setScale(0.075);

    const closeDialog = () => {
      const game = scene.scene.get(Play.key);
      game.events.emit(EVENTS.KEYS.EXIT_DIALOG);
      scene.sound.play("flip", {
        rate: 1.5,
      });
    };

    this.on(
      "pointerdown",
      (
        _p: unknown,
        _x: unknown,
        _y: unknown,
        e: Phaser.Types.Input.EventData
      ) => {
        e.stopPropagation();
        closeDialog();
      }
    );
    scene.input.keyboard?.on("keydown-ESC", () => {
      closeDialog();
    });
    scene.add.existing(this);
  }
}
