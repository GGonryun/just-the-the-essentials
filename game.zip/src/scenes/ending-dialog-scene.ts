import { CHARACTERS } from "../data/characters";
import { EVENTS } from "../data/events";
import { REGISTRY } from "../data/registry";
import { DialogTextBox } from "../objects/dialog-text-box";
import { Portrait } from "../objects/portrait";
import { emitGameEvent } from "../util";

export type EndingDialogSettings = {
  isGameOver: boolean;
};

export class EndingDialog extends Phaser.Scene {
  static key = "ending-dialog";
  dialogMargin = 64;
  dialogPadding = 16;
  dialogHeight = 200;
  constructor() {
    super(EndingDialog.key);
  }

  create() {
    const { height, width } = this.cameras.main;
    const portrait = new Portrait(
      this,
      width * 0.5,
      height / 2.3,
      false,
      CHARACTERS.MYSTERIOUS_ENTITY.MENACING.key
    ).setAlpha(1);
    portrait.setScale(Portrait.scale * 1.1);
    portrait.background.width = width * 2;
    portrait.background.x = 0;

    const settings: EndingDialogSettings = this.registry.get(
      REGISTRY.KEYS.ENDING_DIALOG
    );

    console.log("ending dialog", settings);
    const gameOver1 = [
      {
        title: "Mysterious Entity",
        text: "HOLD IT!! You thought you could go on that easily... despite your careless mistakes?",
        style: "center" as const,
        onStart: () => {},
      },
    ];

    const gameContinue1 = [
      {
        title: "Mysterious Entity",
        text: "Ha! You thought you could get away with that?",
        style: "center" as const,
        onStart: () => {},
      },
      {
        title: "Mysterious Entity",
        text: "Oh wait, looks like you did. Well then, good job!",
        style: "center" as const,
      },
    ];

    const conversationOptions = settings.isGameOver
      ? [gameOver1]
      : [gameContinue1];
    const conversation = Phaser.Math.RND.pick(conversationOptions);

    const dialog = new DialogTextBox(
      this,
      this.dialogMargin / 2,
      height - this.dialogHeight,
      {
        margin: this.dialogMargin,
        padding: this.dialogPadding,
        height: this.dialogHeight,
        conversation,
      }
    );

    dialog.onPointerDown = () => {
      dialog.nextConversation();
    };

    dialog.onConversationStart = (step: number) => {
      const conv = conversation[step];
      conv.onStart?.();
    };

    dialog.onConversationOver = () => {
      if (settings.isGameOver) {
        emitGameEvent(this, EVENTS.KEYS.GAME_OVER);
      } else {
        emitGameEvent(this, EVENTS.KEYS.CONTINUE_LEVEL);
      }
    };

    dialog.nextConversation();
  }
}
