import { EVENTS } from "../data/events";
import { ActiveItem, ItemKey, ITEMS } from "../data/items";
import { REGISTRY } from "../data/registry";
import { DialogSelection } from "../data/selection";
import { ContinueButton } from "../objects/continue-button";
import { Floor } from "../objects/floor";
import { ItemsManager } from "../objects/items-manager";
import { ScoreKeeper } from "../objects/score-keeper";
import { Dialog } from "./dialog-scene";
import { EndingDialog, EndingDialogSettings } from "./ending-dialog-scene";
import { GameOver } from "./game-over-scene";
import { TutorialDialog } from "./tutorial-scene";

export class Play extends Phaser.Scene {
  static key = "Play";

  blur?: Phaser.FX.Blur;
  items: ItemsManager;
  floor: Floor;
  continue: ContinueButton;
  score: ScoreKeeper;

  constructor() {
    super(Play.key);
  }

  create() {
    this.sound.stopAll();
    this.sound.play("gameplay", {
      loop: true,
      volume: 0.15,
    });

    this.cameras.main.setZoom(1);

    this.score = new ScoreKeeper(this);

    this.floor = new Floor(this, 0, 0, 10, 14);

    this.items = new ItemsManager(this, this.floor.bounds());

    this.continue = new ContinueButton(this);

    this.createEvents();
  }

  createEvents() {
    this.events.on(EVENTS.KEYS.PLAY_AGAIN, () => {
      this.resumeScene();
      this.resetRegistry();
      this.items.restart();
      this.score.reset();
      this.continue.setVisible(false);
      this.scene.stop(GameOver.key);
    });

    this.events.on(EVENTS.KEYS.NEXT_LEVEL, () => {
      const valid = this.items.validateSelections();
      if (!valid) {
        this.registry.set(
          REGISTRY.KEYS.REPORT,
          this.items.getIncorrectSelections()
        );
      }

      this.events.emit(EVENTS.KEYS.START_ENDING_DIALOG, !valid);
    });

    this.events.on(EVENTS.KEYS.CONTINUE_LEVEL, () => {
      this.scene.stop(EndingDialog.key);
      this.score.add(1);
      this.items.restart();
      this.continue.setVisible(false);
      this.resetRegistry();

      this.resumeScene();
    });

    this.events.on(EVENTS.KEYS.LEVEL_COMPLETE, () => {
      this.continue.setVisible(true);
    });

    this.events.on(EVENTS.KEYS.EXIT_DIALOG, () => {
      this.resumeScene();
      this.scene.stop(Dialog.key);
    });

    this.events.on(EVENTS.KEYS.ITEM_CLICKED, (item: ItemKey) => {
      const index = Phaser.Math.RND.integerInRange(
        0,
        ITEMS[item].dialogs.length - 1
      );
      console.log("picking a dialog option", index);
      const selection: ActiveItem = {
        key: item,
        dialogIndex: index,
      };
      this.registry.set(REGISTRY.KEYS.ACTIVE, selection);

      this.scene.launch(Dialog.key);
      this.pauseScene();
    });

    this.events.on(EVENTS.KEYS.DIALOG, (choice: DialogSelection) => {
      this.resumeScene();
      this.makeSelection(choice);
      this.scene.stop(Dialog.key);
    });

    this.events.on(EVENTS.KEYS.START_ENDING_DIALOG, (isGameOver: boolean) => {
      this.scene.stop(Dialog.key);
      this.scene.launch(EndingDialog.key);
      const settings: EndingDialogSettings = { isGameOver };
      this.registry.set(REGISTRY.KEYS.ENDING_DIALOG, settings);
      this.pauseScene();
    });

    this.events.on(EVENTS.KEYS.GAME_OVER, () => {
      this.scene.stop(EndingDialog.key);
      this.scene.launch(GameOver.key);
    });

    this.events.on(EVENTS.KEYS.SHOW_TUTORIAL_DIALOG, () => {
      this.scene.launch(TutorialDialog.key);
      this.scene.pause();
    });

    this.events.on(EVENTS.KEYS.CLOSE_TUTORIAL_DIALOG, () => {
      this.scene.stop(TutorialDialog.key);
      const state = this.registry.get(REGISTRY.KEYS.TUTORIAL);
      if (!state) {
        this.scene.stop(EndingDialog.key);
        this.scene.launch(GameOver.key);
        this.registry.set(
          REGISTRY.KEYS.REPORT,
          this.items.getIncorrectSelections()
        );
      } else {
        this.resumeScene();
      }
    });

    this.events.on("shutdown", () => {
      this.events.off(EVENTS.KEYS.DIALOG);
      this.events.off(EVENTS.KEYS.ITEM_CLICKED);
      this.events.off(EVENTS.KEYS.EXIT_DIALOG);
      this.events.off(EVENTS.KEYS.LEVEL_COMPLETE);
      this.events.off(EVENTS.KEYS.NEXT_LEVEL);
      this.events.off(EVENTS.KEYS.GAME_OVER);
      this.events.off(EVENTS.KEYS.PLAY_AGAIN);
      this.events.off(EVENTS.KEYS.CONTINUE_LEVEL);
      this.events.off(EVENTS.KEYS.START_ENDING_DIALOG);
      this.events.off(EVENTS.KEYS.SHOW_TUTORIAL_DIALOG);
      this.events.off(EVENTS.KEYS.CLOSE_TUTORIAL_DIALOG);
    });
  }

  resetRegistry() {
    this.registry.remove(REGISTRY.KEYS.ACTIVE);
    this.registry.remove(REGISTRY.KEYS.ENDING_DIALOG);
    this.registry.remove(REGISTRY.KEYS.REPORT);
  }

  makeSelection(choice: DialogSelection) {
    const selection = this.registry.get(REGISTRY.KEYS.ACTIVE) as ActiveItem;

    this.items.used(selection, choice);
    if (this.items.allUsed()) {
      this.sound.play("cupboard");
      this.events.emit(EVENTS.KEYS.LEVEL_COMPLETE);
    }

    const tutorial = this.registry.get(REGISTRY.KEYS.TUTORIAL);
    console.log("tutorial state", tutorial);
    if (tutorial == null) {
      this.events.emit(EVENTS.KEYS.SHOW_TUTORIAL_DIALOG);
      const soFar = this.items.validateSelections();
      console.log("success so far", soFar);
      this.registry.set(REGISTRY.KEYS.TUTORIAL, soFar);
    }
  }

  resumeScene() {
    if (this.blur) {
      this.cameras.main.postFX.remove(this.blur);
      this.blur?.destroy();
      this.blur = undefined;
    }

    this.scene.resume();
  }

  pauseScene() {
    this.scene.pause();
    if (!this.blur) {
      this.blur = this.cameras.main.postFX.addBlur(0, 1, 1, 1, 0xf1f1f1, 8);
    }
  }
}
