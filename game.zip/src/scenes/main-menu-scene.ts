import { Credits } from "./credits-scene";
import { OpeningDialog } from "./opening-dialog-scene";
import { VolumeMenu } from "./volume-menu-scene";

export class MainMenu extends Phaser.Scene {
  static key = "MainMenu";
  constructor() {
    super(MainMenu.key);
  }
  create() {
    const { height, width } = this.cameras.main;
    this.sound.stopAll();
    this.sound.play("background", {
      loop: true,
      volume: 0.25,
    });
    this.sound.play("dining-clink", {
      loop: true,
      volume: 0.5,
    });
    this.add
      .image(width * 0.5, height * 0.5, "main-menu-background")
      .setOrigin(0.5)
      .setScale(0.6);

    this.add
      .image(width * 0.5, height * 0.5, "game-title")
      .setOrigin(0.5)
      .setScale(0.11);

    const buttonLeftOffset = 164;
    this.add
      .image(width * 0.5 - buttonLeftOffset, height * 0.57, "start-button")
      .setOrigin(0.5)
      .setScale(0.15)
      .setInteractive()
      .on("pointerdown", () => {
        this.scene.start(OpeningDialog.key);
        this.sound.play("flip", {
          rate: 1.5,
        });
      });
    this.add
      .image(width * 0.5 - buttonLeftOffset, height * 0.72, "credits-button")
      .setOrigin(0.5)
      .setScale(0.15)
      .setInteractive()
      .on("pointerdown", () => {
        this.scene.start(Credits.key);
        this.sound.play("flip", {
          rate: 1.5,
        });
      });
    this.add
      .image(width * 0.5 - buttonLeftOffset, height * 0.87, "volume-button")
      .setOrigin(0.5)
      .setScale(0.15)
      .setInteractive()
      .on("pointerdown", () => {
        this.scene.start(VolumeMenu.key);
        this.sound.play("flip", {
          rate: 1.5,
        });
      });
  }
}
