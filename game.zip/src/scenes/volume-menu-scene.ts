import { MainMenu } from "./main-menu-scene";

export class VolumeMenu extends Phaser.Scene {
  static key = "VolumeScene";
  constructor() {
    super(VolumeMenu.key);
  }

  create() {
    const { height, width } = this.cameras.main;
    this.add
      .image(width * 0.5, height * 0.5, "main-menu-background")
      .setOrigin(0.5)
      .setScale(0.6);

    this.add
      .image(width * 0.5, height * 0.5, "volume-window")
      .setOrigin(0.5)
      .setScale(0.13);

    const volumes = [0, 0.25, 0.5, 0.75, 1];
    const currentVolume = volumes.indexOf(this.sound.volume);
    const round = Math.floor(volumes[currentVolume] * 100);

    const volume = this.add
      .image(width * 0.5, height * 0.5, `volume-${round}`)
      .setOrigin(0.5)
      .setScale(0.15)
      .setInteractive()
      .on("pointerdown", () => {
        const volumes = [0, 0.25, 0.5, 0.75, 1];
        const currentVolume = volumes.indexOf(this.sound.volume);
        const nextVolume = (currentVolume + 1) % volumes.length;
        this.sound.volume = volumes[nextVolume];
        const round = Math.floor(volumes[nextVolume] * 100);
        console.log("volume", round);
        volume.setTexture(`volume-${round}`);
        this.sound.play("flip", {
          rate: 1.5,
        });
      });

    this.add
      .image(width * 0.28, height * 0.25, "back-button")
      .setOrigin(0.5)
      .setScale(0.1)
      .setInteractive()
      .on("pointerdown", () => {
        this.scene.start(MainMenu.key);
        this.sound.play("flip", {
          rate: 1.5,
        });
      });
  }
}
