import Phaser from "phaser";
import { ITEMS } from "../data/items";
import { REGISTRY } from "../data/registry";
import { THEME } from "../data/theme";
import { emitGameEvent } from "../util";
import { EVENTS } from "../data/events";
import { ActiveItemSelection } from "../objects/items-manager";
import { MainMenu } from "./main-menu-scene";
import { Play } from "./play-scene";

const GAME_OVER_EVENTS = {
  SEE_DETAILS: "see-details",
  REPORT_CARD: "report-card",
};

const growTween = (target: Phaser.GameObjects.Image, scale: number = 0.65) => ({
  targets: target,
  scale,
  duration: 2000,
  delay: 0,
  ease: "Linear",
  repeat: 0,
  yoyo: false,
});

const fadeTween = (target: Phaser.GameObjects.Image) => ({
  targets: target,
  alpha: 0,
  duration: 1500,
  delay: 500,
  ease: "Linear",
  repeat: 0,
  yoyo: false,
});

export class GameOver extends Phaser.Scene {
  static key = "game-over";
  details: GameOverDetails;
  reportCard: ReportCard;
  constructor() {
    super(GameOver.key);
  }

  create() {
    const explosionScale = 0.05;

    this.time.delayedCall(0, () => {
      this.sound.play("explosion", {
        volume: 0.1,
      });
      const explosion1 = this.add
        .image(
          this.cameras.main.width * 0.5,
          this.cameras.main.height * 0.5,
          "explosion-1"
        )
        .setAlpha(1)
        .setOrigin(0.5)
        .setScale(explosionScale);
      this.tweens.add(growTween(explosion1));
      this.tweens.add(fadeTween(explosion1));

      const smokeStack = this.add
        .image(
          this.cameras.main.width * 0.5,
          this.cameras.main.height * 0.5,
          "smoke-scroll"
        )
        .setAlpha(0)
        .setScale(0.5);

      this.tweens.add({
        // smoke stack slides up and expands and fades out.
        targets: smokeStack,
        y: smokeStack.y - 600,
        scale: 1,
        alpha: 1,
        duration: 5000,
        ease: "Linear",
        repeat: 0,
      });
    });

    this.time.delayedCall(300, () => {
      const explosion2 = this.add
        .image(
          this.cameras.main.width * 0.5,
          this.cameras.main.height * 0.5,
          "explosion-2"
        )
        .setAlpha(1)
        .setOrigin(0.5)
        .setScale(explosionScale);
      this.tweens.add(growTween(explosion2));
      this.tweens.add(fadeTween(explosion2));
    });

    this.time.delayedCall(600, () => {
      const explosion3 = this.add
        .image(
          this.cameras.main.width * 0.5,
          this.cameras.main.height * 0.5,
          "explosion-3"
        )
        .setAlpha(1)
        .setOrigin(0.5)
        .setScale(explosionScale);

      this.tweens.add(growTween(explosion3, 1.2));
      this.tweens.add(fadeTween(explosion3));

      const blackOut = this.add
        .image(
          this.cameras.main.width / 2,
          this.cameras.main.height / 2,
          "explosion"
        )
        .setTintFill(0x000000)
        .setAlpha(0)
        .setScale(0.4)
        .setOrigin(0.5);

      this.tweens.add({
        targets: blackOut,
        alpha: 1,
        duration: 4000,
        ease: "Linear",
        repeat: 0,
        yoyo: false,
        callbackScope: this,
        onComplete() {
          this.showEverything();
        },
      });
    });
  }

  showEverything() {
    const { width, height } = this.scale;
    const centerWidth = width / 2;

    this.reportCard = new ReportCard(this, centerWidth, height / 2, 480, 720);

    this.details = new GameOverDetails(this, centerWidth, height / 2, 480, 720);
    this.details.setVisible(false);

    this.createEvents();
  }

  createEvents() {
    this.events.on(
      GAME_OVER_EVENTS.SEE_DETAILS,
      (data: ActiveItemSelection) => {
        this.details.setItem(data);
        this.details.setVisible(true);
        this.reportCard.setVisible(false);
      }
    );

    this.events.on(GAME_OVER_EVENTS.REPORT_CARD, () => {
      this.details.setVisible(false);
      this.reportCard.setVisible(true);
    });

    this.events.on("shutdown", () => {
      this.events.off(GAME_OVER_EVENTS.SEE_DETAILS);
      this.events.off(GAME_OVER_EVENTS.REPORT_CARD);
    });
  }
}

class ReportCard extends Phaser.GameObjects.Container {
  scene: Phaser.Scene;
  size: { width: number; height: number };
  page = 0;
  pageSize = 5;
  content: Phaser.GameObjects.GameObject[] = [];
  report: ActiveItemSelection[];
  arrowOffset = 42;
  arrowLeft: Phaser.GameObjects.Image;
  arrowRight: Phaser.GameObjects.Image;
  constructor(
    scene: Phaser.Scene,
    x: number,
    y: number,
    width: number,
    height: number
  ) {
    super(scene, x, y);
    this.scene = scene;
    this.size = { width, height };

    this.report = scene.registry.get(REGISTRY.KEYS.REPORT) ?? [];

    const rectangle = scene.add.rexRoundRectangle(
      0,
      0,
      width,
      height,
      32,
      THEME.WHITE.HEX,
      1
    );

    this.add(rectangle);

    this.renderArrows();
    this.renderContent();

    scene.add.existing(this);
  }

  renderArrows() {
    const { width, height } = this.size;

    this.arrowLeft = this.scene.add
      .image(-width / 2 + this.arrowOffset, height * 0.4, "arrow-right")
      .setScale(0.2)
      .setFlipX(true)
      .setVisible(false)
      .setInteractive()
      .on("pointerdown", () => {
        this.pageLeft();
        this.scene.sound.play("flip", {
          rate: 1.5,
        });
      });

    this.arrowRight = this.scene.add
      .image(width / 2 - this.arrowOffset, height * 0.4, "arrow-right")
      .setScale(0.2)
      .setInteractive()
      .setVisible(this.report.length > this.pageSize)
      .on("pointerdown", () => {
        this.pageRight();
        this.scene.sound.play("flip", {
          rate: 1.5,
        });
      });

    this.add(this.arrowLeft);
    this.add(this.arrowRight);
  }

  pageLeft() {
    if (this.page === 0) return;
    this.page--;
    this.renderContent();
    if (this.report.length > this.pageSize) {
      this.arrowRight.setVisible(true);
    }
    if (this.page === 0) {
      this.arrowLeft.setVisible(false);
    }
  }

  pageRight() {
    if (this.page > this.report.length / this.pageSize) return;
    this.page++;
    this.renderContent();
    this.arrowLeft.setVisible(true);
    if (this.page === Math.floor(this.report.length / this.pageSize)) {
      this.arrowRight.setVisible(false);
    }
  }

  cleanOld() {
    this.content.forEach((item) => item.destroy());
  }

  renderContent() {
    this.cleanOld();
    const {
      size: { width, height },
      scene,
    } = this;

    const reportPage = [
      ...this.report
        .slice(
          this.page * this.pageSize,
          this.page * this.pageSize + this.pageSize
        )
        .entries(),
    ];

    const title = this.scene.add
      .text(0, -height * 0.425, "Game Over", {
        fontFamily: "pangolin",
        fontSize: "64px",
        color: THEME.BLACK.CODE,
      })
      .setOrigin(0.5);

    const retry = scene.add
      .image(84, height * 0.4, "retry-button")
      .setScale(0.155)
      .setInteractive()
      .on("pointerdown", () => {
        emitGameEvent(scene, EVENTS.KEYS.PLAY_AGAIN);
        this.scene.sound.play("flip", {
          rate: 1.5,
        });
      });

    const home = scene.add
      .image(-84, height * 0.4, "home-button")
      .setScale(0.155)
      .setInteractive()
      .on("pointerdown", () => {
        scene.scene.stop(GameOver.key);
        scene.scene.stop(Play.key);
        scene.scene.start(MainMenu.key);
        this.scene.sound.play("flip", {
          rate: 1.5,
        });
      });

    for (const [index, item] of reportPage) {
      const onClick = () => {
        scene.events.emit(GAME_OVER_EVENTS.SEE_DETAILS, item);
        this.scene.sound.play("flip", {
          rate: 1.5,
        });
      };
      const cross = scene.add
        .image(-width / 2 + 64, -height * 0.35 + index * 96, "exit")
        .setScale(3)
        .setOrigin(0)
        .setInteractive()
        .on("pointerdown", onClick);
      const portrait = scene.add
        .image(
          -width / 2 + 96,
          -height * 0.3 + index * 96,
          ITEMS[item.key].portrait.key
        )
        .setScale(0.03)
        .setInteractive()
        .on("pointerdown", onClick);

      const name = scene.add
        .text(
          -width / 2 + 132,
          -height * 0.33 + index * 96,
          ITEMS[item.key].name,
          {
            fontFamily: "pangolin",
            fontSize: "32px",
            color: THEME.BLACK.CODE,
          }
        )
        .setInteractive()
        .on("pointerdown", onClick);

      const dialog = scene.add
        .text(
          -width / 2 + 132,
          -height * 0.35 + index * 96 + 48,
          "Click to see details",
          {
            fontFamily: "pangolin",
            fontSize: "18px",
            color: THEME.BLACK.CODE,
            wordWrap: {
              width: width - 96,
            },
          }
        )
        .setInteractive()
        .on("pointerdown", onClick);

      this.add(portrait);
      this.add(cross);
      this.add(name);
      this.add(dialog);
      this.content.push(portrait, cross, name, dialog);
    }

    this.add(title);
    this.add(retry);
    this.add(home);

    this.content.push(title, retry, home);
  }
}

class GameOverDetails extends Phaser.GameObjects.Container {
  dialogOffset = 48;
  scene: Phaser.Scene;
  size: { width: number; height: number };
  constructor(
    scene: Phaser.Scene,
    x: number,
    y: number,
    width: number,
    height: number
  ) {
    super(scene, x, y);
    this.size = { width, height };
    this.scene = scene;
    scene.add.existing(this);
  }

  setItem(active: ActiveItemSelection) {
    const { width, height } = this.size;
    const scene = this.scene;
    const item = ITEMS[active.key];
    const dialog = item.dialogs[active.dialogIndex];

    const rectangle = scene.add.rexRoundRectangle(
      0,
      0,
      width,
      height,
      32,
      THEME.WHITE.HEX,
      1
    );

    const picture = scene.add
      .image(0, -height * 0.225, item.portrait.key)
      .setScale(0.08);

    const title = scene.add
      .text(0, -height * 0.425, item.name, {
        fontFamily: "pangolin",
        fontSize: "48px",
        color: THEME.BLACK.CODE,
        wordWrap: {
          width,
        },
      })
      .setOrigin(0.5);

    const iconX = -width / 2 + this.dialogOffset * 0.25;
    const textX = -width / 2 + this.dialogOffset;
    const topY = -height * 0.025;
    const botY = height * 0.1;
    const textWrapWidth = width - this.dialogOffset * 1.5;

    const topIcon = scene.add
      .image(iconX, topY, dialog.answer === "left" ? "check" : "exit")
      .setScale(2)
      .setOrigin(0);
    const topText = scene.add
      .text(textX, topY, dialog.left, {
        fontFamily: "pangolin",
        fontSize: "18px",
        color: "#000",
        align: "left",
        wordWrap: {
          width: textWrapWidth,
        },
      })
      .setAlign("left");

    const botIcon = scene.add
      .image(iconX, botY, dialog.answer === "right" ? "check" : "exit")
      .setScale(2)
      .setOrigin(0);

    const botText = scene.add.text(textX, botY, dialog.right, {
      fontFamily: "pangolin",
      fontSize: "18px",
      color: "#000",
      align: "left",
      wordWrap: {
        width: textWrapWidth,
      },
    });

    const taunt = scene.add
      .text(0, height * 0.275, dialog.gameOver, {
        fontFamily: "pangolin",
        fontSize: "22px",
        color: "#000",
        fontStyle: "italic",
        wordWrap: {
          width: textWrapWidth,
        },
      })
      .setOrigin(0.5);

    const back = scene.add
      .image(0, height * 0.425, "back-button")
      .setScale(0.1)
      .setInteractive()
      .on("pointerdown", () => {
        this.scene.events.emit(GAME_OVER_EVENTS.REPORT_CARD, active);
        this.scene.sound.play("flip", {
          rate: 1.5,
        });
      });

    this.add(rectangle);
    this.add(picture);
    this.add(title);
    this.add(topIcon);
    this.add(topText);
    this.add(botIcon);
    this.add(botText);
    this.add(taunt);
    this.add(back);
  }
}
