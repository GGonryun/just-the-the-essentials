import { Scene } from "phaser";
import { ITEM_KEYS, ITEMS } from "../data/items";
import { FLOOR_TILE_KEYS } from "../data/tiles";
import { MainMenu } from "./main-menu-scene";
import { CHARACTERS } from "../data/characters";

export class Boot extends Scene {
  static key = "Boot";

  constructor() {
    super(Boot.key);
  }

  preload() {
    this.createEvents();

    this.load.image("cursor", "assets/cursor/pointer.png");
    this.load.image("exit", "assets/exit.png");
    this.load.image("check", "assets/check.png");
    this.load.image("pointer", "assets/pointer.png");
    this.load.image("continue", "assets/continue.png");
    this.load.image("explosion", "assets/explosion.jpg");
    this.load.image("center-text-box", "assets/ui/center-text-box.png");
    this.load.image("left-text-box", "assets/ui/left-text-box.png");
    this.load.image("right-text-box", "assets/ui/right-text-box.png");
    this.load.image("arrow-right", "assets/ui/arrow-right.png");
    this.load.image("exit-button", "assets/ui/exit-button.png");
    this.load.image("back-button", "assets/ui/back-button.png");
    this.load.image("retry-button", "assets/ui/retry-button.png");
    this.load.image("home-button", "assets/ui/home-button.png");
    this.load.image("credits-button", "assets/ui/credits-button.png");
    this.load.image("credits-page", "assets/ui/credits-page.png");
    this.load.image("game-title", "assets/ui/game-title.png");
    this.load.image(
      "main-menu-background",
      "assets/ui/main-menu-background.png"
    );
    this.load.image("volume-window", "assets/ui/volume-window.png");
    this.load.image("volume-0", "assets/ui/volume-0.png");
    this.load.image("volume-25", "assets/ui/volume-25.png");
    this.load.image("volume-50", "assets/ui/volume-50.png");
    this.load.image("volume-75", "assets/ui/volume-75.png");
    this.load.image("volume-100", "assets/ui/volume-100.png");
    this.load.image("start-button", "assets/ui/start-button.png");
    this.load.image("volume-button", "assets/ui/volume-button.png");
    this.load.image("next-room-button", "assets/ui/next-room-button.png");

    for (const key of ITEM_KEYS) {
      const item = ITEMS[key];
      for (const sprite of item.sprites) {
        this.load.image(sprite.key, sprite.path);
      }
      this.load.image(item.portrait.key, item.portrait.path);
    }

    for (const key of FLOOR_TILE_KEYS) {
      this.load.image(key, `assets/floor/${key}.png`);
    }

    for (const key in CHARACTERS.POINTER) {
      const emotion =
        CHARACTERS.POINTER[key as keyof typeof CHARACTERS.POINTER];
      this.load.image(emotion.key, emotion.path);
    }

    for (const key in CHARACTERS.MYSTERIOUS_ENTITY) {
      const emotion =
        CHARACTERS.MYSTERIOUS_ENTITY[
          key as keyof typeof CHARACTERS.MYSTERIOUS_ENTITY
        ];
      this.load.image(emotion.key, emotion.path);
    }

    this.load.image("cut-scene-1", "assets/cut-scenes/1.png");
    this.load.image("cut-scene-2", "assets/cut-scenes/2.png");
    this.load.image("cut-scene-3", "assets/cut-scenes/3.png");

    this.load.image("explosion-1", "assets/game-over/explosion-1.png");
    this.load.image("explosion-2", "assets/game-over/explosion-2.png");
    this.load.image("explosion-3", "assets/game-over/explosion-3.png");
    this.load.image("smoke-scroll", "assets/game-over/smoke-scroll.png");

    this.load.audio("cupboard", "assets/audio/cupboard.mp3");
    this.load.audio("dining-clink", "assets/audio/dining-clink.mp3");
    this.load.audio("door-close", "assets/audio/door-close.mp3");
    this.load.audio("door-open", "assets/audio/door-open.mp3");
    this.load.audio("explosion", "assets/audio/explosion.mp3");
    this.load.audio("hits", "assets/audio/hits.mp3");
    this.load.audio("flip", "assets/audio/flip.mp3");
    this.load.audio("bubble", "assets/audio/thumb.mp3");
    this.load.audio("item-pick", "assets/audio/bubble.mp3");
    this.load.audio("dialog", "assets/audio/dialog.mp3");
    this.load.audio("dialog-2", "assets/audio/dialog-2.mp3");
    this.load.audio("background", "assets/audio/background.mp3");
    this.load.audio("gameplay", "assets/audio/gameplay.mp3");
    this.load.audio("toggle", "assets/audio/toggle.mp3");
  }

  createEvents() {
    this.load.on("complete", () => {
      this.input.setDefaultCursor("url(assets/cursor/pointer.png), default");
      this.scene.start(MainMenu.key);
    });
  }
}
