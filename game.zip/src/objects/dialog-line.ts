export class DialogLine extends Phaser.GameObjects.Container {
  graphics: Phaser.GameObjects.Graphics;
  line: Phaser.Geom.Line;
  constructor(scene: Phaser.Scene) {
    super(scene, 0, 0);
    const { height, width } = scene.cameras.main;
    this.graphics = scene.add.graphics({
      lineStyle: { width: 2, color: 0x000000 },
    });
    this.line = new Phaser.Geom.Line(width / 2, 0, width / 2, height);
    this.graphics.strokeLineShape(this.line);
  }

  hide() {
    this.graphics.clear();
  }

  show() {
    this.graphics.strokeLineShape(this.line);
  }
}
