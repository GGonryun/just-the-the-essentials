export class ScoreKeeper {
  scene: Phaser.Scene;
  score: number;
  text: Phaser.GameObjects.Text;
  constructor(scene: Phaser.Scene) {
    this.scene = scene;
    this.score = 0;

    this.text = scene.add.text(12, 6, this.fmt(), {
      fontFamily: "pangolin",
      fontSize: "32px",
      color: "#000",
    });
  }

  fmt() {
    return `Score: ${this.score}`;
  }

  get() {
    return this.score;
  }

  set(score: number) {
    this.score = score;
    this.text.setText(this.fmt());
  }

  add(points: number) {
    const current = this.get();
    this.set(current + points);
  }

  reset() {
    this.set(0);
  }
}
