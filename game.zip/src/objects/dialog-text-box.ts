export type ConversationOption = {
  title: string;
  text: string;
  style: "left" | "right" | "center" | "none";
};
export type DialogOptions = {
  height: number;
  margin: number;
  padding: number;
  conversation: ConversationOption[];
};

export type DialogTemplate = {
  rectangle: {
    x: number;
    y: number;
    key: string;
  };
  title: {
    x: number;
    y: number;
  };
  arrow: {
    x: number;
    y: number;
  };
};

export class DialogTextBox extends Phaser.GameObjects.Container {
  step: number;
  text: Phaser.GameObjects.Text;
  rightArrow: Phaser.GameObjects.Image;
  opts: DialogOptions;
  rectangle: Phaser.GameObjects.Image;
  title: Phaser.GameObjects.Text;
  onPointerDown?: (step: number) => void;
  onConversationStart?: (step: number) => void;
  onConversationEnd?: (step: number) => void;
  onConversationOver?: () => void;
  isTalking: boolean;
  conversation: ConversationOption[];
  abort: AbortController;
  templates: {
    left: DialogTemplate;
    right: DialogTemplate;
    center: DialogTemplate;
    none: DialogTemplate;
  };

  constructor(scene: Phaser.Scene, x: number, y: number, opts: DialogOptions) {
    const { width } = scene.cameras.main;
    super(scene, x, y);
    this.scene = scene;
    this.setDepth(100);
    this.isTalking = false;
    this.step = 0;
    this.opts = opts;
    this.abort = new AbortController();
    this.templates = {
      left: {
        rectangle: {
          x: 0,
          y: -60,
          key: "left-text-box",
        },
        title: {
          x: 180,
          y: -40,
        },
        arrow: {
          x: width - 128,
          y: opts.height - 72,
        },
      },
      center: {
        rectangle: {
          x: 0,
          y: -36,
          key: "center-text-box",
        },
        title: {
          x: 152,
          y: -12,
        },
        arrow: {
          x: width - 128,
          y: opts.height - 116,
        },
      },
      none: {
        rectangle: {
          x: 0,
          y: -36,
          key: "center-text-box",
        },
        title: {
          x: 152,
          y: -12,
        },
        arrow: {
          x: width - 128,
          y: opts.height - 116,
        },
      },
      right: {
        rectangle: {
          x: 0,
          y: -48,
          key: "right-text-box",
        },
        title: {
          x: width - 358,
          y: -24,
        },
        arrow: {
          x: width - 128,
          y: opts.height - 112,
        },
      },
    };
    this.conversation = opts.conversation;

    const start = "left";
    const settings = this.templates[start];

    this.rectangle = scene.add
      .image(0, settings.rectangle.y, settings.rectangle.key)
      .setScale(0.38)
      .setOrigin(0);

    this.title = scene.add.text(settings.title.x, settings.title.y, "", {
      fontFamily: "pangolin",
      color: "black",
      fontSize: "32px",
      fontStyle: "bold",
      wordWrap: { width: width },
    });
    this.text = scene.add.text(100, 62, "", {
      fontFamily: "pangolin",
      color: "black",
      fontSize: "24px",
      wordWrap: { width: width - 275 },
    });

    this.rightArrow = scene.add
      .image(settings.arrow.x, settings.arrow.y, "arrow-right")
      .setOrigin(0.5)
      .setScale(0.23)
      .setTintFill(0x000000);

    // add a tween to make the arrow bounce
    scene.tweens.add({
      targets: this.rightArrow,
      x: settings.arrow.x + 10,
      duration: 250,
      yoyo: true,
      repeat: -1,
    });

    this.add(this.rectangle);
    this.add(this.title);
    this.add(this.text);
    this.add(this.rightArrow);

    scene.add.existing(this);

    scene.input?.on("pointerdown", () => {
      if (this.isTalking) {
        this.abort.abort();
      } else {
        this.onPointerDown?.(this.step);
        scene.sound.play("bubble", {
          volume: 0.5,
        });
      }
    });
  }

  async nextConversation() {
    if (this.step >= this.conversation.length) {
      this.onConversationOver?.();
      return;
    } else if (this.step < this.conversation.length) {
      const conversation = this.conversation[this.step];
      await this.startTalking(
        conversation.title,
        conversation.text,
        conversation.style,
        this.step === this.conversation.length - 1
      );
    } else {
      this.rightArrow.setVisible(false);
    }
    this.step++;
  }

  async startTalking(
    title: string,
    text: string,
    style: "left" | "right" | "center" | "none",
    hideNext = false
  ) {
    this.abort = new AbortController();
    const settings = this.templates[style];
    if (hideNext) {
      this.rightArrow.setVisible(false);
    } else {
      this.rightArrow.setVisible(true);
    }
    this.rectangle.setTexture(settings.rectangle.key);
    this.rectangle.setPosition(settings.rectangle.x, settings.rectangle.y);
    this.title.setPosition(settings.title.x, settings.title.y);
    this.title.setText(title);
    this.title.setFontSize(title.length > 11 ? "26px" : "32px");
    this.rightArrow.setPosition(settings.arrow.x, settings.arrow.y);

    this.rightArrow.setVisible(false);
    this.scene.sound.play("dialog", {
      loop: true,
    });
    this.scene.sound.play("dialog-2", {
      loop: true,
      volume: 0.05,
    });
    this.onConversationStart?.(this.step);
    this.isTalking = true;
    await this.streamText(text);
    this.isTalking = false;
    this.scene.sound.stopByKey("dialog");
    this.scene.sound.stopByKey("dialog-2");
    this.onConversationEnd?.(this.step);
    this.rightArrow.setVisible(true);
  }

  streamText(text: string) {
    const streamTextSpeed = 20;
    return new Promise((resolve) => {
      let i = 0;
      const interval = setInterval(() => {
        this.text.setText(text.substring(0, i));
        i++;
        if (i > text.length) {
          clearInterval(interval);
          resolve(true);
        }
      }, streamTextSpeed);
      this.abort.signal.addEventListener("abort", () => {
        clearInterval(interval);
        this.text.setText(text);
        resolve(true);
      });
    });
  }
}
