import { FLOOR_TILES, TILE, TILE_SCALE } from "../data/tiles";

export type FloorBounds = {
  x: number;
  y: number;
  height: number;
  width: number;
  tiles: {
    width: number;
    height: number;
  };
};

export class Floor extends Phaser.GameObjects.Container {
  static tileOffset = 1;
  scene: Phaser.Scene;
  tileHeight: number;
  tileWidth: number;

  constructor(
    scene: Phaser.Scene,
    x: number,
    y: number,
    height: number,
    width: number
  ) {
    super(scene, x, y);
    this.scene = scene;
    this.tileHeight = height;
    this.tileWidth = width;

    for (let i = 0; i < height; i++) {
      for (let j = 0; j < width; j++) {
        this.placeTile(i, j);
      }
    }

    scene.add.existing(this);
  }

  placeTile(i: number, j: number) {
    const isTop = i === 0;
    const isBottom = i === this.tileHeight - 1;
    const isLeft = j === 0;
    const isRight = j === this.tileWidth - 1;

    if (isTop && isLeft) {
      return this.place(i, j, "top-left");
    }
    if (isTop && isRight) {
      return this.place(i, j, "top-right");
    }
    if (isBottom && isLeft) {
      return this.place(i, j, "bottom-left");
    }
    if (isBottom && isRight) {
      return this.place(i, j, "bottom-right");
    }
    if (isTop) {
      return this.place(i, j, "top-middle");
    }
    if (isBottom) {
      return this.place(i, j, "bottom-middle");
    }
    if (isLeft) {
      return this.place(i, j, "middle-left");
    }
    if (isRight) {
      return this.place(i, j, "middle-right");
    }
    this.place(i, j, "middle");
  }

  place(j: number, i: number, key: keyof typeof FLOOR_TILES) {
    const { x, y } = Floor.tileToWorld(i, j);
    const tile = this.scene.add.image(x, y, key);
    tile.setScale(TILE_SCALE);
    this.add(tile);
  }

  static tileToWorld(x: number, y: number) {
    return {
      x: (x + this.tileOffset) * TILE.width + TILE.width / 2,
      y: (y + this.tileOffset) * TILE.height + TILE.height / 2,
    };
  }

  static worldToTile(x: number, y: number) {
    return {
      x: Math.floor((x - TILE.width / 2) / TILE.width - this.tileOffset),
      y: Math.floor((y - TILE.height / 2) / TILE.height - this.tileOffset),
    };
  }

  bounds(): FloorBounds {
    return {
      tiles: {
        width: this.tileWidth,
        height: this.tileHeight,
      },
      x: Floor.tileOffset * TILE.width,
      y: Floor.tileOffset * TILE.height,
      width: this.tileWidth * TILE.width,
      height: this.tileHeight * TILE.height,
    };
  }
}
