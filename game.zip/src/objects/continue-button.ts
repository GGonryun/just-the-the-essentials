import { EVENTS } from "../data/events";

export class ContinueButton extends Phaser.GameObjects.Image {
  constructor(scene: Phaser.Scene) {
    const { width, height } = scene.cameras.main;
    super(scene, width - 32, height - 32, "next-room-button");
    this.setVisible(false);
    this.setScale(0.15);
    this.setOrigin(1);
    this.setInteractive().on("pointerdown", () => {
      scene.events.emit(EVENTS.KEYS.NEXT_LEVEL);
      this.scene.sound.play("flip", {
        rate: 1.5,
      });
    });
    this.setDepth(100);
    scene.add.existing(this);
  }
}
