import { EVENTS } from "../data/events";
import { ItemKey, ITEMS } from "../data/items";
import { TILE } from "../data/tiles";

export class ClickableItem extends Phaser.GameObjects.Container {
  image: Phaser.GameObjects.Image;
  pointer: Phaser.GameObjects.Image;
  tween: Phaser.Tweens.Tween;
  key: ItemKey;
  isUsed: boolean;
  constructor(scene: Phaser.Scene, x: number, y: number, key: ItemKey) {
    super(scene, x, y);
    this.isUsed = false;
    this.key = key;
    const originalPointerScale = 0.025;
    const item = ITEMS[key];
    const spriteIndex = Phaser.Math.Between(0, item.sprites.length - 1);
    const image = item.sprites[spriteIndex];

    this.image = scene.add
      .image(-TILE.width / 2, ((image.height - 1) * TILE.height) / 2, image.key)
      .setScale(0.065)
      .setOrigin(0, 0.5)
      .setInteractive()
      .setDepth(0)
      .on("pointerdown", () => {
        scene.events.emit(EVENTS.KEYS.ITEM_CLICKED, key);
        scene.sound.play("item-pick", {
          rate: 1.5,
        });
      });

    this.pointer = scene.add
      .image(0, -50, "pointer")
      .setScale(originalPointerScale)
      .setVisible(true)
      .setDepth(1);

    this.tween = scene.tweens.add({
      targets: this.pointer,
      scale: originalPointerScale * 1.4,
      y: -64,
      duration: 300,
      yoyo: true,
      repeat: -1,
    });

    this.add(this.image);
    this.add(this.pointer);
    scene.add.existing(this);
  }

  used() {
    this.isUsed = true;
    this.image.removeInteractive();
    this.pointer.setVisible(false);
    this.tween.remove();
  }
}
