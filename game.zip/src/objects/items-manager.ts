import { ActiveItem, ITEM_KEYS, ItemKey, ITEMS } from "../data/items";
import { DialogSelection } from "../data/selection";
import { ClickableItem } from "./clickable-item";
import { Floor, FloorBounds } from "./floor";

export type ActiveItemSelection = ActiveItem & { choice: DialogSelection };

export class ItemsManager {
  scene: Phaser.Scene;
  bounds: FloorBounds;
  items: ClickableItem[];
  selections: ActiveItemSelection[];
  spawnOffset = 2;
  spawnRadius = 1;
  itemsPerLevel = 5;
  constructor(scene: Phaser.Scene, bounds: FloorBounds) {
    this.scene = scene;
    this.bounds = bounds;

    this.items = [];
    this.selections = [];

    this.randomlySpawn(this.itemsPerLevel);
  }

  randomlySpawn(count: number) {
    const keys = [...ITEM_KEYS];
    const randomized = Phaser.Math.RND.shuffle(keys);
    const spawning = randomized.splice(0, count);
    spawning.forEach((key) => this.spawn(key));
  }

  restart() {
    this.items.forEach((item) => item.destroy());
    this.items = [];
    this.selections = [];

    this.randomlySpawn(this.itemsPerLevel);
  }

  spawn(key: ItemKey) {
    const x = Phaser.Math.Between(
      this.spawnOffset,
      this.bounds.tiles.width - this.spawnOffset
    );
    const y = Phaser.Math.Between(
      this.spawnOffset,
      this.bounds.tiles.height - this.spawnOffset
    );

    const world = Floor.tileToWorld(x, y);
    const closest = this.closest(world.x, world.y);
    if (closest) {
      const test = Floor.worldToTile(closest.x, closest.y);
      const canPlace = Math.abs(test.x - x) > 1 && Math.abs(test.y - y) > 1;
      if (!canPlace) {
        this.spawn(key);
        return;
      }
    }

    this.items.push(new ClickableItem(this.scene, world.x, world.y, key));
  }

  closest(x: number, y: number) {
    if (!this.items.length) {
      return undefined;
    }
    let closest = this.items[0];
    let closestDistance = Phaser.Math.Distance.Between(
      x,
      y,
      closest.x,
      closest.y
    );

    for (const item of this.items) {
      const distance = Phaser.Math.Distance.Between(x, y, item.x, item.y);
      if (distance < closestDistance) {
        closest = item;
        closestDistance = distance;
      }
    }

    return closest;
  }

  used(selection: ActiveItem, choice: DialogSelection) {
    const item = this.items.find((item) => item.key === selection.key);
    if (!item) {
      alert(
        "Item not found, something went wrong. Please scold the developer."
      );
      return;
    }
    item.used();

    // save the selection and choice
    this.selections.push({ ...selection, choice });
  }

  allUsed() {
    return this.items.every((item) => item.isUsed);
  }

  countUsed() {
    return this.items.filter((item) => item.isUsed).length;
  }

  validateSelections() {
    return this.selections.every((selection) => {
      const item = ITEMS[selection.key];
      if (!item) {
        alert(
          "Item not found, something went wrong. Please scold the developer."
        );
        return false;
      }
      const dialog = item.dialogs[selection.dialogIndex];
      if (!dialog) {
        alert(
          "Dialog not found, something went wrong. Please scold the developer."
        );
        return false;
      }

      return dialog.answer === selection.choice;
    });
  }

  getIncorrectSelections() {
    return this.selections.filter((selection) => {
      const item = ITEMS[selection.key];
      if (!item) {
        alert(
          "Item not found, something went wrong. Please scold the developer."
        );
        return false;
      }
      const dialog = item.dialogs[selection.dialogIndex];
      if (!dialog) {
        alert(
          "Dialog not found, something went wrong. Please scold the developer."
        );
        return false;
      }

      return dialog.answer !== selection.choice;
    });
  }
}
