import { EVENTS } from "../data/events";
import { SELECTION } from "../data/selection";
import { Play } from "../scenes/play-scene";

export class Portrait extends Phaser.GameObjects.Image {
  background: Phaser.GameObjects.Rectangle;
  tween?: Phaser.Tweens.Tween;
  originalY: number;
  static scale: number = 0.2;
  constructor(
    scene: Phaser.Scene,
    x: number,
    y: number,
    isLeft: boolean,
    sprite: string
  ) {
    super(scene, x, y, sprite);
    this.originalY = y;
    this.setScale(Portrait.scale);
    this.setOrigin(0.5);
    isLeft && this.setFlipX(true);

    const onClick = () => {
      const game = scene.scene.get(Play.key);
      game.events.emit(
        EVENTS.KEYS.DIALOG,
        isLeft ? SELECTION.RIGHT : SELECTION.LEFT
      );
    };

    this.on(
      "pointerover",
      () => {
        this.setInitialChoice(true);
      },
      this
    );

    this.on("pointerout", () => {
      this.setInitialChoice(false);
    }).on("pointerdown", onClick);

    const { height, width } = scene.cameras.main;
    this.background = scene.add
      .rectangle(x, y, width / 2, height * 2, 0x000000, 0.5)
      .setOrigin(0.5)
      .on(
        "pointerover",
        () => {
          this.setInitialChoice(true);
          this.scene.sound.play("toggle");
        },
        this
      )
      .on(
        "pointerout",
        () => {
          this.setInitialChoice(false);
        },
        this
      )
      .on("pointerdown", onClick, this);

    scene.add.existing(this);
  }

  enableInteractions() {
    this.background.setInteractive();
  }

  setInitialChoice(selected: boolean) {
    if (selected) {
      this.setAlpha(1);
      this.background.setFillStyle(0x00ff00, 0.5);
      if (this.tween) {
        return;
      }
      this.tween = this.scene.tweens.add({
        targets: this,
        y: this.y - 25,
        scale: Portrait.scale * 1.05,
        duration: 250,
        yoyo: true,
        repeat: -1,
      });
    } else {
      this.setAlpha(0.25);
      this.y = this.originalY;
      this.background.setFillStyle(0xff0000, 0.5);
      this.setScale(Portrait.scale);
      if (this.tween) {
        this.tween.stop();
        this.tween.remove();
        this.tween = undefined;
      }
    }
  }
}
