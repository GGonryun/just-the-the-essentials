export const ITEMS = {
  "axolotl-plush": {
    key: "axolotl-plush",
    name: "Axolotl Plush",
    sprites: [
      {
        key: "axolotl-plush-sprite",
        path: "assets/sprites/axolotl-plush.png",
        height: 1,
        width: 1,
      },
    ],
    portrait: {
      key: "axolotl-plush-portrait",
      path: "assets/portraits/axolotl-plush.png",
    },
    dialogs: [
      {
        left: "This is the stuffed axolotl. This particular creature is known as the Mexican salamander.",
        right:
          "No, this is the stuffed axolotl. Did you know all axolotls are a vibrant pink color? It’s the truth, really!",
        answer: "left",
        gameOver: "Don't trust everything you read on the internet.",
      },
      {
        left: "This is the stuffed axolotl. The animal it is modeled after may attempt to eat its aquarium buddies. It’s the truth, just ask Bubbles! Wait... where’s Bubbles?",
        right:
          "No, this is the stuffed axolotl. Did you know all axolotls are a vibrant pink color? It’s the truth, really!",
        answer: "left",
        gameOver: "Let's work on those trust issues of yours...",
      },
    ],
  },
  "bintendo-swatch": {
    key: "bintendo-swatch",
    name: "Bintendo Swatch",
    sprites: [
      {
        key: "bintendo-swatch-horizontal-sprite",
        path: "assets/sprites/bintendo-swatch-horizontal.png",
        height: 1,
        width: 2,
      },
      {
        key: "bintendo-swatch-vertical-sprite",
        path: "assets/sprites/bintendo-swatch-vertical.png",
        height: 2,
        width: 1,
      },
    ],
    portrait: {
      key: "bintendo-swatch-portrait",
      path: "assets/portraits/bintendo-swatch.png",
    },
    dialogs: [
      {
        left: "This is the Bintendo Swatch. It is a video game console with three modes of play: TV, Tabletop, and Handheld.",
        right:
          "No, this is the Bintendo Swatch. It is a video game console with three modes of play: TV, Stovetop, and Handheld.",
        answer: "left",
        gameOver: "Really cooking with that second mode of play there.",
      },
      {
        left: "This is the Bintendo Swatch. It is Bintendo's best-selling gaming console. And the best one, period!",
        right:
          "No, this is the Bintendo Swatch. It is Bintendo's second best-seller. And an alright one.",
        answer: "right",
        gameOver:
          "You 'drifted' pretty far from the answer there. The Clamshell sold better. The generation before the swatch was better, too! This generation just doesn’t get it!",
      },
    ],
  },
  bleach: {
    key: "bleach",
    name: "Concentrated Bleach",
    sprites: [
      {
        key: "bleach-sprite",
        path: "assets/sprites/bleach.png",
        height: 1,
        width: 1,
      },
    ],
    portrait: {
      key: "bleach-portrait",
      path: "assets/portraits/bleach.png",
    },
    dialogs: [
      {
        left: "This is the concentrated Bleach. This is a manga series by Tite Kubo which later received an anime adaptation.",
        right:
          "No, this is the concentrated Bleach. A specialized bleach with enhanced microbial-killing capabilities.",
        answer: "right",
        gameOver: "Touch some grass and do your laundry.",
      },
      {
        left: "This is the concentrated bleach. Diluting it to a 10% solution is a standard practice to use as a disinfectant.",
        right:
          "No, this is the concentrated bleach. It is compatible with just about any other cleaning agent.",
        answer: "left",
        gameOver: "Congratulations on accidentally creating a toxic gas!",
      },
    ],
  },
  blender: {
    key: "blender",
    name: "Blender",
    sprites: [
      {
        key: "blender-sprite",
        path: "assets/sprites/blender.png",
        height: 1,
        width: 1,
      },
    ],
    portrait: {
      key: "blender-portrait",
      path: "assets/portraits/blender.png",
    },
    dialogs: [
      {
        left: "This is the blender. It is software with the potential to create animated films, art, 3D-printed models, and so much more.",
        right:
          "No, this is the blender. It is a kitchen appliance with the potential to create smoothies, blend various foods, and much more.",
        answer: "right",
        gameOver: "So close yet so far.",
      },
      {
        left: "This is the blender. This is a kitchen accessory so beloved that as of 2018, 90% of households owned at least one blender.",
        right:
          "No, this is the blender. This is a kitchen accessory that recommends putting both hot and cold liquids in it.",
        answer: "left",
        gameOver:
          "Do not try to be special. Be like everyone else. Buy a blender. Or a burn kit.",
      },
    ],
  },
  cactus: {
    key: "cactus",
    name: "Cactus",
    sprites: [
      {
        key: "cactus-sprite",
        path: "assets/sprites/cactus.png",
        height: 1,
        width: 1,
      },
    ],
    portrait: {
      key: "cactus-portrait",
      path: "assets/portraits/cactus.png",
    },
    dialogs: [
      {
        left: "This is the cactus. All of them are smooth plants.",
        right: "No, this is the cactus. Some are prickly plants.",
        answer: "right",
        gameOver: "Pet any Opuntia Cactus and return to report your findings.",
      },
      {
        left: "This is the cactus. The Opuntia cactus is a prickly plant and may be spotted in dry areas.",
        right:
          "No, this is the cactus. The Opuntia cactus plant bears no flowers and cannot survive indoors.",
        answer: "left",
        gameOver:
          "With proper care, the opuntia cactus, also known as a prickly pear cactus, can be a nice houseplant.",
      },
    ],
  },
  "clothing-rack": {
    key: "clothing-rack",
    name: "Clothing Rack",
    sprites: [
      {
        key: "clothing-rack-horizontal-sprite",
        path: "assets/sprites/clothing-rack-horizontal.png",
        height: 1,
        width: 2,
      },
      {
        key: "clothing-rack-vertical-sprite",
        path: "assets/sprites/clothing-rack-vertical.png",
        height: 2,
        width: 1,
      },
    ],
    portrait: {
      key: "clothing-rack-portrait",
      path: "assets/portraits/clothing-rack.png",
    },
    dialogs: [
      {
        left: "This is the clothing rack. Compact, affordable, and durable, this piece of furniture is utilized to display one's clothing.",
        right:
          "No, this is the clothing rack. It is a modern structure that doubles as a bed frame or a plant display case.",
        answer: "left",
        gameOver:
          "Hm, a bit too outside the box. Take a good long look at the name.",
      },
      {
        left: "This is the clothing rack. The pole also doubles as a self-defense weapon for retail store workers.",
        right:
          "No, this is the clothing rack. It was originally used as a convenient piece of furniture so clothes would not get crumpled up in boxes.",
        answer: "right",
        gameOver:
          "You cannot hit people with clothing rack poles. Hope this helps!",
      },
    ],
  },
  "crossroad-sign": {
    key: "crossroad-sign",
    name: "Crossroad Sign",
    sprites: [
      {
        key: "crossroad-sign-sprite",
        path: "assets/sprites/crossroad-sign.png",
        height: 1,
        width: 1,
      },
    ],
    portrait: {
      key: "crossroad-sign-portrait",
      path: "assets/portraits/crossroad-sign.png",
    },
    dialogs: [
      {
        left: "This is the crossroad sign. It is a sign that informs drivers of a four-way intersection.",
        right:
          "No, this is the crossroad sign. It informs an individual they are at a point in their life where they must make a significant decision or turning point.",
        answer: "left",
        gameOver:
          "Please study for your permit test. Your mom cannot drive you to Game Jam forever.",
      },
      {
        left: "This is the crossroad sign. Like other warning signs on California roads, it is green and in the shape of an octagon.",
        right:
          "No, this is the crossroad sign. Like other warning signs on California roads, it is yellow and in the shape of a diamond.",
        answer: "right",
        gameOver:
          "Being a passenger princess isn't so bad, you can refresh yourself with the California Drivers' Handbook.",
      },
    ],
  },
  "edamame-beans": {
    key: "edamame-beans",
    name: "Edamame Beans",
    sprites: [
      {
        key: "edamame-beans-sprite",
        path: "assets/sprites/edamame-beans.png",
        height: 1,
        width: 1,
      },
    ],
    portrait: {
      key: "edamame-beans-portrait",
      path: "assets/portraits/edamame-beans.png",
    },
    dialogs: [
      {
        left: "These are the edamummy beans. It is a tasty snack consisting of boiled or steamed soybeans that were first cultivated in Egypt over 7,000 years ago.",
        right:
          "No, these are the edamame beans. It is a tasty snack consisting of boiled or steamed soybeans that may or may not be salted and or served with other condiments such as spicy sauce.",
        answer: "right",
        gameOver: "Wrap it up, edadummy. It's edamame's turn.",
      },
      {
        left: "This is the edamame beans. They are green in color",
        right: "No, this is the edamame beans. They are pink in color.",
        answer: "left",
        gameOver: "Is the pink in the room with us right now?",
      },
    ],
  },
  "fire-hydrant": {
    key: "fire-hydrant",
    name: "Fire Hydrant",
    sprites: [
      {
        key: "fire-hydrant-sprite",
        path: "assets/sprites/fire-hydrant.png",
        height: 1,
        width: 1,
      },
    ],
    portrait: {
      key: "fire-hydrant-portrait",
      path: "assets/portraits/fire-hydrant.png",
    },
    dialogs: [
      {
        left: "This is a fire hydrant. Often colored purple, it is a connection point for firefighters to tap into a water supply.",
        right:
          "No, this is a fire hydrant. Often colored red, it is a connection point for firefighters to tap into a water supply.",
        answer: "right",
        gameOver:
          "Dude, this fire hydrant is red. You're colorblind. Game over.",
      },
      {
        left: "This is a fire hydrant. It is a connection point for firefighters to tap into a water supply.",
        right:
          "No, this is a fire hydrant. It is a connection point for police to tap into a water supply.",
        answer: "left",
        gameOver: "placeholder",
      },
    ],
  },
  frisbee: {
    key: "frisbee",
    name: "Frisbee",
    sprites: [
      {
        key: "frisbee-sprite",
        path: "assets/sprites/frisbee.png",
        height: 1,
        width: 1,
      },
    ],
    portrait: {
      key: "frisbee-portrait",
      path: "assets/portraits/frisbee.png",
    },
    dialogs: [
      {
        left: "This is the frisbee. Though frisbees are currently plastic, the first frisbee was a garbage can lid.",
        right:
          "No, this is the frisbee. It is a flying disk thrown for fun and sport, the latter of which is under governance by the World Flying Disc Federation.",
        answer: "right",
        gameOver:
          "While a pie would be thrown in your face for getting that wrong, the first frisbees were empty pie tins.",
      },
      {
        left: "This is the frisbee. This toy was inspired by elementary students tossing pie tins.",
        right:
          "No, this is the frisbee. The cremated remains of the inventor of the frisbee were turned into a frisbee.",
        answer: "right",
        gameOver: "You're never too old to have fun.",
      },
    ],
  },
  mannequin: {
    key: "Mannequin",
    name: "Mannequin",
    sprites: [
      {
        key: "mannequin-horizontal-sprite",
        path: "assets/sprites/mannequin-horizontal.png",
        height: 1,
        width: 2,
      },
      {
        key: "mannequin-vertical-sprite",
        path: "assets/sprites/mannequin-vertical.png",
        height: 2,
        width: 1,
      },
    ],
    portrait: {
      key: "mannequin-portrait",
      path: "assets/portraits/mannequin.png",
    },
    dialogs: [
      {
        left: "This is the mannequin. Often spotted in apparel stores modeling various outfits, the design of the mannequin itself has remained the same since its debut in the 15th century.",
        right:
          "No, this is the mannequin. Similar to the clothes it wears, the mannequin changes designs.",
        answer: "right",
        gameOver: "Nothing's perfect...",
      },
      {
        left: "This is the mannequin. The first female mannequins were made of paper-mache.",
        right:
          "No, this is the mannequin. The first female mannequins were made of wood.",
        answer: "left",
        gameOver: "Man, I can not believe you wooden get that one.",
      },
    ],
  },
  "mini-fridge": {
    key: "mini-fridge",
    name: "Mini Fridge",
    sprites: [
      {
        key: "mini-fridge-horizontal-sprite",
        path: "assets/sprites/mini-fridge-horizontal.png",
        height: 1,
        width: 2,
      },
      {
        key: "mini-fridge-vertical-sprite",
        path: "assets/sprites/mini-fridge-vertical.png",
        height: 2,
        width: 1,
      },
    ],
    portrait: {
      key: "mini-fridge-portrait",
      path: "assets/portraits/mini-fridge.png",
    },
    dialogs: [
      {
        left: "This is the mini-fridge. It is a compact and freestanding appliance that refrigerates its contents with at most two drawers and a spot for drinks.",
        right:
          "This is the micro-fridge. It is an appliance made up of a fridge, freezer, and microwave.",
        answer: "left",
        gameOver: "In many cases, less is more. This is one of them.",
      },
      {
        left: "This is the mini-fridge. This small appliance has a capacity of about 25 L and often comes with a lock.",
        right:
          "No, this is the mini-fridge. This small appliance has a capacity of about 100 L and most do not come with a lock.",
        answer: "right",
        gameOver:
          "Sharing is caring, now go ask for someone to share their notes with you.",
      },
    ],
  },
  rope: {
    key: "rope",
    name: "Rope",
    sprites: [
      {
        key: "rope-horizontal-sprite",
        path: "assets/sprites/rope-horizontal.png",
        height: 1,
        width: 2,
      },
      {
        key: "rope-vertical-sprite",
        path: "assets/sprites/rope-vertical.png",
        height: 2,
        width: 1,
      },
    ],
    portrait: {
      key: "rope-portrait",
      path: "assets/portraits/rope.png",
    },
    dialogs: [
      {
        left: "This is the rope. It is made of twisted or braided yarns, plies, fibers, or strands.",
        right:
          "This is the rope. At no point in time was it made of leather, grass, and animal hairs.",
        answer: "left",
        gameOver:
          "Fun fact: Ancient Egyptians made rope with leather, grass, and animal hairs! Not so fun fact: You were wrong.",
      },
      {
        left: "This is the rope. This is a tool whose strongest point is located at the place a knot is created.",
        right:
          "No, this is the rope. This is a tool of multiple uses, one such being the Mega Swing in Utah which swings out over a 400-foot cliff.",
        answer: "right",
        gameOver: "Trivia isn't your strong point, is it?",
      },
    ],
  },
  satellite: {
    key: "satellite",
    name: "Satellite Dish",
    sprites: [
      {
        key: "satellite-sprite",
        path: "assets/sprites/satellite.png",
        height: 2,
        width: 2,
      },
    ],
    portrait: {
      key: "satellite-portrait",
      path: "assets/portraits/satellite.png",
    },
    dialogs: [
      {
        left: "This is the satellite dish. It is a type of parabolic antenna that often receives satellite television.",
        right:
          "No, this is the satellite dish. It is a foreign cuisine consisting of space junk and a parabolic antenna.",
        answer: "left",
        gameOver:
          "Just because we have TV dinners does not mean we should eat the satellite television for dinner.",
      },
      {
        left: "This is the satellite dish. It communicates with satellites currently in orbit around the Earth, over 9000!",
        right:
          "No, this is the satellite dish. You need a satellite dish to communicate with satellites.",
        answer: "left",
        gameOver: "How do you think your phone GPS works?",
      },
    ],
  },
  shoes: {
    key: "shoes",
    name: "Shoes",
    sprites: [
      {
        key: "shoes-sprite",
        path: "assets/sprites/shoes.png",
        height: 1,
        width: 1,
      },
    ],
    portrait: {
      key: "shoes-portrait",
      path: "assets/portraits/shoes.png",
    },
    dialogs: [
      {
        left: "These are the shoes. This is a gesture done to convey when one ought to beat feet.",
        right:
          "No, these are the shoes. This potentially fashionable and collectible protective wear engulfs feet.",
        answer: "right",
        gameOver:
          "Wrong choice but a shoe could be used to shoo someone away if you throw it hard enough...",
      },
      {
        left: "These are the shoes. Depending on where you are, the sizing system of shoes change.",
        right: "These are the shoes. The sizing of shoes is universal.",
        answer: "left",
        gameOver: "Perhaps you didn't know because you wear clown shoes.",
      },
    ],
  },
  "stack-of-books": {
    key: "stack-of-books",
    name: "Stack of Books",
    sprites: [
      {
        key: "stack-of-books",
        path: "assets/sprites/stack-of-books.png",
        height: 1,
        width: 1,
      },
    ],
    portrait: {
      key: "stack-of-books-portrait",
      path: "assets/portraits/stack-of-books.png",
    },
    dialogs: [
      {
        left: "This is the stock book. A book full of tips and tricks regarding the stock market and investing.",
        right:
          "No, this is the book stack. A plethora of books of various potential subjects piled up one on top of the other.",
        answer: "right",
        gameOver:
          "A tad too specific. Open your mind, expand into vague potential stacks instead of just stocks.",
      },
      {
        left: "This is the stack of books. There is a 16-foot-tall stack of books dedicated to the 16th president of the United States.",
        right:
          "No, this is the stack of books. In 2012 a team of three broke the record for the tallest stack of Guinness World Records in one minute.",
        answer: "right",
        gameOver:
          "Did you go to Game Jam alone because you have no friends, or do you have no friends because you go to Game Jam?",
      },
    ],
  },
  stoat: {
    key: "stoat",
    name: "Stoat Plush",
    sprites: [
      {
        key: "stoat-sprite",
        path: "assets/sprites/stoat.png",
        height: 1,
        width: 1,
      },
    ],
    portrait: {
      key: "stoat-portrait",
      path: "assets/portraits/stoat.png",
    },
    dialogs: [
      {
        left: "This is the stuffed stoat. It is a plushie of a beloved animal in the Muridae family.",
        right:
          "No, this is the stuffed stoat. It is a plushie of a beloved animal in the Mustelid family.",
        answer: "right",
        gameOver:
          "Does this darling creature really look like it is a part of the rat family?",
      },
      {
        left: "This is the stuffed stoat. The animal this plush is based on is an herbivore.",
        right:
          "No, this is the stuffed stoat. The animal this plush is based on likes to eat rabbits.",
        answer: "right",
        gameOver: "Don't judge a stoat by its coat.",
      },
    ],
  },
  "stuffed-goat": {
    key: "stuffed-goat",
    name: "Stuffed Goat",
    sprites: [
      {
        key: "stuffed-goat-horizontal-sprite",
        path: "assets/sprites/stuffed-goat-horizontal.png",
        height: 1,
        width: 2,
      },
      {
        key: "stuffed-goat-vertical-sprite",
        path: "assets/sprites/stuffed-goat-vertical.png",
        height: 2,
        width: 1,
      },
    ],
    portrait: {
      key: "stuffed-goat-portrait",
      path: "assets/portraits/stuffed-goat.png",
    },
    dialogs: [
      {
        left: "This is the stuffed goat. It is a plushie of a horned animal that likes grass and is an excellent climber.",
        right:
          "This is the stuffed goat. It is a plushie of a horned animal that is not related to sheep.",
        answer: "left",
        gameOver:
          "If you ever bothered to attend the family reunions, you would see that sheep and goats are related.",
      },
      {
        left: "This is the stuffed goat. The animal this plush is based on is so loving that it has three hearts!",
        right:
          "No, this is the stuffed goat. The animal this plush is based on has four-chambered stomachs.",
        answer: "right",
        gameOver: "Try stomaching this: you were wrong. Womp womp.",
      },
    ],
  },
  "t-rex": {
    key: "t-rex",
    name: "Articulated T-Rex",
    sprites: [
      {
        key: "t-rex-horizontal-sprite",
        path: "assets/sprites/t-rex-horizontal.png",
        height: 1,
        width: 2,
      },
      {
        key: "t-rex-vertical-sprite",
        path: "assets/sprites/t-rex-vertical.png",
        height: 2,
        width: 1,
      },
    ],
    portrait: {
      key: "t-rex-portrait",
      path: "assets/portraits/t-rex.png",
    },
    dialogs: [
      {
        left: "This is the Articulated T-Rex Model. It is a posable figure modeled after a bipedal herbivore, a Tyrannosaurus rex.",
        right:
          "No, this is the Articulated T-Rex Model. It is a posable figure modeled after a 40 foot long theropod dinosaur known as the Tyrannosaurus rex.",
        answer: "right",
        gameOver: "Silly meathead, a theropod is a flesh-eating dinosaur.",
      },
      {
        left: "This is the Articulated Trex Model. The dinosaur this figure is modeled after lived in the Mesozoic era.",
        right:
          "No, this is the Articulated Trex Model. The dinosaur this figure is modeled after lived in the Cenozoic era.",
        answer: "left",
        gameOver: "You are currently in the Flop era.",
      },
    ],
  },
  "tea-kettle": {
    key: "tea-kettle",
    name: "Tea Kettle",
    sprites: [
      {
        key: "tea-kettle-sprite",
        path: "assets/sprites/tea-kettle.png",
        height: 1,
        width: 1,
      },
    ],
    portrait: {
      key: "tea-kettle-portrait",
      path: "assets/portraits/tea-kettle.png",
    },
    dialogs: [
      {
        left: "This is the tea kettle. Some are copper and are used to boil water for various uses such as making tea or 'just add boiled water' foods.",
        right: "No, this is the tea kettle. The pot is always made of steel.",
        answer: "left",
        gameOver:
          "Copper kettles exist too. Expand your mind and your kettle collection.",
      },
      {
        left: "This is the tea kettle. Cowboys made coffee in kettles.",
        right:
          "No, this is the tea kettle. The whistling tea kettle was invented by Barry B. Benson in 1923.",
        answer: "left",
        gameOver:
          "Harry Bramson was an inventor. Barry B. Benson is a fictitious bee who sued the human race over honey.",
      },
    ],
  },
} as const;

export type ItemKey = keyof typeof ITEMS;
export type ActiveItem = {
  key: ItemKey;
  dialogIndex: number;
};
export const ITEM_KEYS = Object.keys(ITEMS) as ItemKey[];

export type ItemDialog = {
  left: string;
  right: string;
  answer: "left" | "right";
  gameOver: string;
};
