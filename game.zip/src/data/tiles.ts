export const TILE_SCALE = 0.25;
export const TILE = {
  height: 250 * TILE_SCALE,
  width: 250 * TILE_SCALE,
};

export const FLOOR_TILES = {
  "bottom-left": {
    key: "bottom-left",
  },
  "bottom-middle": {
    key: "bottom-middle",
  },
  "bottom-right": {
    key: "bottom-right",
  },
  "middle-left": {
    key: "middle-left",
  },
  middle: {
    key: "middle",
  },
  "middle-right": {
    key: "middle-right",
  },
  "top-left": {
    key: "top-left",
  },
  "top-middle": {
    key: "top-middle",
  },
  "top-right": {
    key: "top-right",
  },
};

export const FLOOR_TILE_KEYS = Object.keys(
  FLOOR_TILES
) as (keyof typeof FLOOR_TILES)[];
