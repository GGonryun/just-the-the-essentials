export const REGISTRY = {
  KEYS: {
    ACTIVE: "active",
    REPORT: "report",
    ENDING_DIALOG: "ending-dialog",
    TUTORIAL: "tutorial-state",
  },
};
