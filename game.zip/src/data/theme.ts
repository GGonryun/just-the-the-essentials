export const THEME = {
  WHITE: { HEX: 0xf4e9df, CODE: "#f4e9df" },
  BLACK: { HEX: 0x3a3030, CODE: "#3a3030" },
  ADVANCED_DARKNESS: { HEX: 0x000000, CODE: "#000000" },
};
