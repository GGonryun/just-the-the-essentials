export const EVENTS = {
  KEYS: {
    ITEM_CLICKED: "item-clicked",
    DIALOG: "dialog",
    EXIT_DIALOG: "exit-dialog",
    LEVEL_COMPLETE: "level-complete",
    NEXT_LEVEL: "next-level",
    GAME_OVER: "game-over",
    START_ENDING_DIALOG: "start-ending-dialog",
    PLAY_AGAIN: "play-again",
    CONTINUE_LEVEL: "continue-level",
    SHOW_TUTORIAL_DIALOG: "show-tutorial-dialog",
    CLOSE_TUTORIAL_DIALOG: "close-tutorial-dialog",
  },
};
