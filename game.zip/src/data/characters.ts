export const CHARACTERS = {
  MYSTERIOUS_ENTITY: {
    HAPPY: {
      key: "mysterious-entity-portrait-happy",
      path: "assets/portraits/mysterious-entity/happy.png",
    },
    CURIOUS: {
      key: "mysterious-entity-portrait-curious",
      path: "assets/portraits/mysterious-entity/curious.png",
    },
    MENACING: {
      key: "mysterious-entity-portrait-menacing",
      path: "assets/portraits/mysterious-entity/menacing.png",
    },
    NEUTRAL: {
      key: "mysterious-entity-portrait-neutral",
      path: "assets/portraits/mysterious-entity/neutral.png",
    },
  },
  POINTER: {
    ANGRY: {
      key: "pointer-mc-cursor-portrait-angry",
      path: "assets/portraits/pointer-mc-cursor/angry.png",
    },
    NEUTRAL: {
      key: "pointer-mc-cursor-portrait-neutral",
      path: "assets/portraits/pointer-mc-cursor/neutral.png",
    },
    SURPRISED: {
      key: "pointer-mc-cursor-portrait-surprised",
      path: "assets/portraits/pointer-mc-cursor/surprised.png",
    },
  },
};
