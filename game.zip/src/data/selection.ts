export const SELECTION = {
  RIGHT: "right",
  LEFT: "left",
} as const;

export type DialogSelection = (typeof SELECTION)[keyof typeof SELECTION];
