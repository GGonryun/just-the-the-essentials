import { Play } from "./scenes/play-scene";

export const emitGameEvent = (
  scene: Phaser.Scene,
  event: string,
  ...args: any[]
) => {
  const game = scene.scene.get(Play.key);
  console.log("emitting game event", game);
  game.events.emit(event, ...args);
};
